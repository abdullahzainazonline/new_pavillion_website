export default function Home() {
  return (
    <main style={{
      minHeight: "100vh",
      background: "#0a0a0a",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "Georgia, serif",
      padding: "2rem"
    }}>
      <h1 style={{
        color: "#c9a96e",
        fontSize: "clamp(1.4rem, 4vw, 2.4rem)",
        fontWeight: 300,
        letterSpacing: "0.2em",
        textTransform: "uppercase",
        marginBottom: "0.5rem",
        textAlign: "center"
      }}>
        Pavilion Square
      </h1>
      <p style={{
        color: "#888",
        fontSize: "0.85rem",
        letterSpacing: "0.15em",
        textTransform: "uppercase",
        marginBottom: "2.5rem"
      }}>
        Luxury Residences
      </p>

      <div style={{
        width: "100%",
        maxWidth: "960px",
        borderRadius: "4px",
        overflow: "hidden",
        boxShadow: "0 30px 80px rgba(0,0,0,0.8)"
      }}>
        <video
          src="https://kaoljqciecsnafblzmci.supabase.co/storage/v1/object/public/video/Pavilion_Square_Luxury_Residences_Urban_Luxe_720P.mp4"
          controls
          autoPlay
          muted
          loop
          playsInline
          style={{ width: "100%", display: "block" }}
        />
      </div>
    </main>
  );
}
